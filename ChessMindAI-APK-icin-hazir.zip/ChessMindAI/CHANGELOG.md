# Changelog

## 0.3.0 — board localization + live position analysis

- Added a generic axis-aligned 8x8 checkerboard locator for screenshot crops.
- Fixed square classifier crop-coordinate bug and added safe bitmap lifecycle.
- Added confidence threshold and uncertain-square reporting.
- Connected MediaProjection frame recognition broadcasts to UI FEN updates.
- Added live Stockfish MultiPV analysis only when the recognized position changes.
- Added Android 13+ notification permission declaration.

External TFLite model and Android Stockfish executable are still required; no APK
is claimed as built or tested.
