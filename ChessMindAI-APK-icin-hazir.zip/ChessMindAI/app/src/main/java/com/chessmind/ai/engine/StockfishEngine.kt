package com.chessmind.ai.engine

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.TimeUnit

data class EngineLine(
    val multipv: Int,
    val depth: Int,
    val centipawns: Int?,
    val mate: Int?,
    val pv: List<String>
) {
    val scoreText: String
        get() = mate?.let { "Mat ${kotlin.math.abs(it)}" }
            ?: centipawns?.let { "%+.2f".format(it / 100.0) } ?: "—"
}

data class EngineAnalysis(val lines: List<EngineLine>, val bestMove: String?) {
    val best: EngineLine? get() = lines.firstOrNull()
}

/** UCI adapter. Supply a GPL-compliant Android Stockfish executable in assets. */
class StockfishEngine(private val context: Context) {
    private var process: Process? = null
    private var input: BufferedWriter? = null
    private var output: BufferedReader? = null
    private var uciReady = false

    suspend fun analyze(fen: String, depth: Int = 16, multiPv: Int = 3): Result<EngineAnalysis> =
        withContext(Dispatchers.IO) {
            runCatching {
                require(fen.isNotBlank())
                startIfNeeded()
                if (!uciReady) {
                    send("uci")
                    readUntil("uciok", 10)
                    uciReady = true
                }
                send("setoption name MultiPV value ${multiPv.coerceIn(1, 5)}")
                send("isready")
                readUntil("readyok", 10)
                send("position fen $fen")
                send("go depth ${depth.coerceIn(1, 30)}")
                val info = mutableMapOf<Int, EngineLine>()
                var bestMove: String? = null
                val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(60)
                while (System.nanoTime() < deadline) {
                    val line = output?.readLine() ?: error("Stockfish bağlantısı kapandı")
                    if (line.startsWith("info ")) parseInfo(line)?.let { old ->
                        val previous = info[old.multipv]
                        if (previous == null || old.depth >= previous.depth) info[old.multipv] = old
                    }
                    if (line.startsWith("bestmove ")) {
                        bestMove = line.split(Regex("\\s+" )).getOrNull(1)
                        break
                    }
                }
                if (bestMove == null) error("Stockfish zaman aşımı")
                EngineAnalysis(info.values.sortedBy { it.multipv }, bestMove)
            }
        }

    private fun startIfNeeded() {
        if (process?.isAlive == true) return
        val abi = android.os.Build.SUPPORTED_ABIS.firstOrNull { it in setOf("arm64-v8a", "armeabi-v7a", "x86_64") }
            ?: error("Desteklenen Android ABI bulunamadı")
        val assetPath = "stockfish/$abi/stockfish"
        val executable = File(context.filesDir, "stockfish-$abi")
        context.assets.open(assetPath).use { src -> executable.outputStream().use(src::copyTo) }
        check(executable.setExecutable(true)) { "Stockfish çalıştırılabilir yapılamadı" }
        process = ProcessBuilder(executable.absolutePath).redirectErrorStream(true).start()
        input = BufferedWriter(OutputStreamWriter(process!!.outputStream))
        output = BufferedReader(InputStreamReader(process!!.inputStream))
        uciReady = false
    }

    private fun send(command: String) {
        input?.apply { write(command); newLine(); flush() }
    }

    private fun readUntil(marker: String, seconds: Long) {
        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(seconds)
        while (System.nanoTime() < deadline) {
            val line = output?.readLine() ?: error("Stockfish bağlantısı kapandı")
            if (line.contains(marker)) return
        }
        error("Stockfish zaman aşımı: $marker")
    }

    private fun parseInfo(line: String): EngineLine? {
        val t = line.trim().split(Regex("\\s+"))
        fun value(key: String) = t.indexOf(key).takeIf { it >= 0 }?.let { t.getOrNull(it + 1) }
        val pvIndex = t.indexOf("pv")
        val scoreIndex = t.indexOf("score")
        if (pvIndex < 0 || scoreIndex < 0) return null
        val kind = t.getOrNull(scoreIndex + 1)
        val score = t.getOrNull(scoreIndex + 2)?.toIntOrNull()
        return EngineLine(
            multipv = value("multipv")?.toIntOrNull() ?: 1,
            depth = value("depth")?.toIntOrNull() ?: 0,
            centipawns = if (kind == "cp") score else null,
            mate = if (kind == "mate") score else null,
            pv = t.drop(pvIndex + 1).takeWhile { it != "string" }
        )
    }

    fun close() {
        runCatching { send("quit") }
        process?.destroy()
        process = null
        uciReady = false
    }
}
