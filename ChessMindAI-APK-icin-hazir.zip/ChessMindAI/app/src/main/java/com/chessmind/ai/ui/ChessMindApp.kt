package com.chessmind.ai.ui

import android.graphics.BitmapFactory
import android.net.Uri
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.os.Build
import androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult
import com.chessmind.ai.capture.ScreenCaptureService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.chessmind.ai.chess.FenPosition
import com.chessmind.ai.engine.StockfishEngine
import com.chessmind.ai.engine.EngineAnalysis
import com.chessmind.ai.engine.EngineLine
import com.chessmind.ai.vision.TfliteBoardRecognizer
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

private val Bg = Color(0xFF0B1110)
private val Panel = Color(0xFF151F1C)
private val Green = Color(0xFF37D69A)
private val Muted = Color(0xFF9AA9A2)
private val WhiteText = Color(0xFFEAF2ED)

@Composable
fun ChessMindApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var fen by remember { mutableStateOf(FenPosition.START) }
    var analysis by remember { mutableStateOf<EngineAnalysis?>(null) }
    var status by remember { mutableStateOf("Hazır · Yerel analiz") }
    var busy by remember { mutableStateOf(false) }
    var imageNote by remember { mutableStateOf("Tahta görselini seçin (tahta görüntünün ortasında ve kare olmalı).") }
    var sideToMove by remember { mutableStateOf("w") }
    var castling by remember { mutableStateOf("KQkq") }
    var boardPlacement by remember { mutableStateOf(FenPosition.START.substringBefore(' ')) }
    var blackAtBottom by remember { mutableStateOf(false) }
    var captureActive by remember { mutableStateOf(false) }
    var lastLiveFen by remember { mutableStateOf("") }
    val engine = remember { StockfishEngine(context) }
    val recognizer = remember { TfliteBoardRecognizer(context) }
    val captureLauncher = rememberLauncherForActivityResult(StartActivityForResult()) { result ->
        val data = result.data
        if (result.resultCode == android.app.Activity.RESULT_OK && data != null) {
            val serviceIntent = Intent(context, ScreenCaptureService::class.java)
                .putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                .putExtra(ScreenCaptureService.EXTRA_DATA, data)
                .putExtra(ScreenCaptureService.EXTRA_BLACK_BOTTOM, blackAtBottom)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(serviceIntent)
            else context.startService(serviceIntent)
            captureActive = true
            status = "Canlı ekran takibi başlatıldı · Analiz cihaz üzerinde kalır"
        } else status = "Ekran paylaşımı izni verilmedi"
    }
    DisposableEffect(context) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                when (intent?.action) {
                    ScreenCaptureService.ACTION_POSITION -> {
                        val detected = intent.getStringExtra(ScreenCaptureService.EXTRA_FEN)
                        val confidence = intent.getFloatExtra(ScreenCaptureService.EXTRA_CONFIDENCE, 0f)
                        if (detected != null && FenPosition.isValid(detected) && confidence >= 0.55f) {
                            boardPlacement = detected.substringBefore(' ')
                            val updatedFen = "$boardPlacement $sideToMove ${castling.ifBlank { "-" }} - 0 1"
                            fen = FenPosition(updatedFen)
                            imageNote = "Canlı tahta algılandı · Güven %.0f%%".format(confidence * 100)
                            // Avoid re-running the engine on every identical screen frame.
                            if (updatedFen != lastLiveFen) {
                                lastLiveFen = updatedFen
                                scope.launch {
                                    engine.analyze(updatedFen, 14, 3).onSuccess { analysis = it }
                                        .onFailure { status = it.message ?: "Canlı Stockfish analizi başarısız" }
                                }
                            }
                        }
                    }
                    ScreenCaptureService.ACTION_ERROR -> imageNote = intent.getStringExtra(ScreenCaptureService.EXTRA_ERROR) ?: "Canlı analiz hatası"
                }
            }
        }
        val filter = IntentFilter().apply {
            addAction(ScreenCaptureService.ACTION_POSITION)
            addAction(ScreenCaptureService.ACTION_ERROR)
        }
        if (Build.VERSION.SDK_INT >= 33) context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") context.registerReceiver(receiver, filter)
        onDispose { runCatching { context.unregisterReceiver(receiver) } }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                busy = true
                imageNote = "Görüntü işleniyor…"
                val bitmap = runCatching {
                    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                }.getOrNull()
                if (bitmap == null) {
                    imageNote = "Görüntü açılamadı. Başka bir dosya deneyin."
                } else {
                    recognizer.recognize(bitmap, blackAtBottom).onSuccess { detection ->
                        boardPlacement = detection.fen.value.substringBefore(' ')
                        fen = FenPosition("$boardPlacement $sideToMove ${castling.ifBlank { "-" }} - 0 1")
                        imageNote = "Tahta algılandı · Güven %.0f%% · Belirsiz kare: %s".format(
                            detection.confidence * 100, detection.uncertainSquares.take(8).joinToString().ifEmpty { "yok" }
                        )
                        status = "Pozisyon tanındı · Hamle sırası ve rok haklarını doğrulayın"
                    }.onFailure { imageNote = it.message ?: "Tahta tanıma başarısız" }
                    bitmap.recycle()
                }
                busy = false
            }
        }
    }
    DisposableEffect(Unit) { onDispose { engine.close(); recognizer.close() } }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Green, onBackground = WhiteText,
        onSurface = WhiteText, onPrimary = Bg
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 22.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("CHESSMIND", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("AI COACH", color = WhiteText, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Surface(color = Panel, shape = RoundedCornerShape(50)) {
                        Text("● ON-DEVICE", Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            color = Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Text("POZİSYON ANALİZİ", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("SIRA", color = Muted, fontSize = 10.sp)
                    FilterChip(selected = sideToMove == "w", onClick = {
                        sideToMove = "w"; fen = FenPosition("$boardPlacement w ${castling.ifBlank { "-" }} - 0 1")
                    }, label = { Text("Beyaz") })
                    FilterChip(selected = sideToMove == "b", onClick = {
                        sideToMove = "b"; fen = FenPosition("$boardPlacement b ${castling.ifBlank { "-" }} - 0 1")
                    }, label = { Text("Siyah") })
                    Text("ROK", color = Muted, fontSize = 10.sp)
                    FilterChip(selected = castling == "-", onClick = {
                        castling = "-"; fen = FenPosition("$boardPlacement $sideToMove - - 0 1")
                    }, label = { Text("Yok") })
                    FilterChip(selected = castling == "KQkq", onClick = {
                        castling = "KQkq"; fen = FenPosition("$boardPlacement $sideToMove KQkq - 0 1")
                    }, label = { Text("Tümü") })
                    FilterChip(selected = blackAtBottom, onClick = { blackAtBottom = !blackAtBottom },
                        label = { Text(if (blackAtBottom) "Siyah altta" else "Beyaz altta") })
                }
                ChessBoard(fen = fen, bestMove = analysis?.best?.pv?.firstOrNull())
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    MetricCard("DEĞERLENDİRME", analysis?.best?.scoreText ?: "—", Modifier.weight(1f))
                    MetricCard("DERİNLİK", analysis?.best?.depth?.toString() ?: "—", Modifier.weight(1f))
                }
                Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                        Text("EN İYİ DEVAM · STOCKFISH", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        val lines = analysis?.lines.orEmpty()
                        if (lines.isEmpty()) Text("Analiz bekleniyor", color = Green, fontSize = 16.sp)
                        lines.forEachIndexed { index, line ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("${index + 1}.", color = Muted, modifier = Modifier.width(22.dp))
                                Text(line.pv.take(6).joinToString(" "), color = WhiteText, modifier = Modifier.weight(1f), fontSize = 13.sp)
                                Text(line.scoreText, color = Green, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text(explain(lines.firstOrNull()), color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        scope.launch {
                            busy = true; status = "Stockfish MultiPV 3 analiz ediyor…"
                            engine.analyze(fen.value, 16, 3).onSuccess {
                                analysis = it; status = "Analiz tamamlandı · ${it.lines.size} varyasyon"
                            }.onFailure { status = it.message ?: "Motor başlatılamadı" }
                            busy = false
                        }
                    }, enabled = !busy, modifier = Modifier.weight(1f).height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Green, contentColor = Bg),
                        shape = RoundedCornerShape(13.dp)) {
                        Text(if (busy) "İŞLENİYOR…" else "ANALİZ ET", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = { picker.launch("image/*") }, enabled = !busy,
                        modifier = Modifier.weight(1f).height(50.dp), shape = RoundedCornerShape(13.dp)) {
                        Text("GÖRSEL YÜKLE", fontSize = 11.sp)
                    }
                }
                OutlinedButton(onClick = {
                    if (captureActive) {
                        context.startService(Intent(context, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP))
                        captureActive = false
                        status = "Canlı ekran takibi durduruldu"
                    } else {
                        val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                        captureLauncher.launch(manager.createScreenCaptureIntent())
                    }
                }, modifier = Modifier.fillMaxWidth().height(46.dp), shape = RoundedCornerShape(13.dp)) {
                    Text(if (captureActive) "CANLI TAKİBİ DURDUR" else "CANLI EKRAN TAKİBİNİ BAŞLAT")
                }
                Text(imageNote, color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
                Text(status, color = Green, fontSize = 11.sp)
                Text("FEN · ${fen.value}", color = Muted, fontSize = 9.sp, lineHeight = 13.sp)
            }
        }
    }
}

private fun explain(line: EngineLine?): String {
    if (line == null || line.pv.isEmpty()) return "Motor analizi tamamlandığında hamle açıklaması burada gösterilir."
    val move = line.pv.first()
    val motif = when {
        line.mate != null -> "Motor zorunlu mat buldu. Öncelik, rakibin şahına karşı kaçış karelerini ve savunma kaynaklarını kontrol etmektir."
        line.centipawns != null && line.centipawns > 120 -> "Bu devam mevcut pozisyonda belirgin üstünlük sağlıyor. Rakibin en güçlü savunmasına karşı varyasyonu takip et."
        line.centipawns != null && line.centipawns < -120 -> "Bu pozisyon analiz edilen taraf için zor. Önce tehditleri karşıla ve taş kaybını önle."
        else -> "${move} motorun en güçlü bulduğu devam. Taş aktivitesi, şah güvenliği ve taktik tehditleri birlikte değerlendir."
    }
    return "Türkçe koç notu: $motif"
}

@Composable
private fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Panel, shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.padding(13.dp)) {
            Text(title, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Text(value, color = Green, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ChessBoard(fen: FenPosition, bestMove: String?) {
    val symbols = mapOf('k' to "♚", 'q' to "♛", 'r' to "♜", 'b' to "♝", 'n' to "♞", 'p' to "♟",
        'K' to "♔", 'Q' to "♕", 'R' to "♖", 'B' to "♗", 'N' to "♘", 'P' to "♙")
    val ranks = fen.value.substringBefore(' ').split("/")
    val squares = ranks.map { rank -> buildList {
        rank.forEach { c -> if (c in '1'..'8') repeat(c.digitToInt()) { add("") } else add(symbols[c] ?: "") }
    } }
    Box(Modifier.fillMaxWidth().aspectRatio(1f).border(1.dp, Color(0xFF35453E))) {
        Column(Modifier.fillMaxSize()) {
            squares.forEachIndexed { r, rank ->
                Row(Modifier.weight(1f)) {
                    rank.forEachIndexed { c, piece ->
                        Box(Modifier.weight(1f).fillMaxHeight()
                            .background(if ((r + c) % 2 == 0) Color(0xFFD9E2D9) else Color(0xFF557565)),
                            contentAlignment = Alignment.Center) {
                            Text(piece, fontSize = 29.sp,
                                color = if (piece.firstOrNull()?.isUpperCase() == true) Color(0xFF18231E) else Color(0xFFFAFAF5))
                        }
                    }
                }
            }
        }
        if (bestMove != null && bestMove.length >= 4) {
            Canvas(Modifier.fillMaxSize()) {
                val fromFile = bestMove[0] - 'a'; val fromRank = 8 - bestMove[1].digitToInt()
                val toFile = bestMove[2] - 'a'; val toRank = 8 - bestMove[3].digitToInt()
                if (fromFile in 0..7 && toFile in 0..7 && fromRank in 0..7 && toRank in 0..7) {
                    val cell = size.width / 8f
                    val start = Offset((fromFile + .5f) * cell, (fromRank + .5f) * cell)
                    val end = Offset((toFile + .5f) * cell, (toRank + .5f) * cell)
                    drawLine(Color(0xFF20E6A0), start, end, strokeWidth = cell * .11f, cap = StrokeCap.Round)
                    val angle = atan2(end.y - start.y, end.x - start.x)
                    val length = cell * .25f
                    val p1 = Offset(end.x - length * cos(angle - PI / 6).toFloat(), end.y - length * sin(angle - PI / 6).toFloat())
                    val p2 = Offset(end.x - length * cos(angle + PI / 6).toFloat(), end.y - length * sin(angle + PI / 6).toFloat())
                    val path = Path().apply { moveTo(end.x, end.y); lineTo(p1.x, p1.y); lineTo(p2.x, p2.y); close() }
                    drawPath(path, Color(0xFF20E6A0))
                }
            }
        }
    }
}
