package com.chessmind.ai.vision

import android.graphics.Bitmap
import android.graphics.Rect
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Locates a flat, axis-aligned 8x8 board in a screenshot by scoring the
 * alternating light/dark square pattern. This is a fast UI-board detector,
 * not a perspective/homography solver: photographed boards need a separate
 * corner detector. Returns coordinates in the source bitmap's pixel space.
 */
object BoardCropper {
    data class Detection(val bounds: Rect, val score: Float)

    fun locate(source: Bitmap): Detection? {
        val scale = min(1f, 420f / max(source.width, source.height))
        val w = max(1, (source.width * scale).toInt())
        val h = max(1, (source.height * scale).toInt())
        val small = if (w == source.width && h == source.height) source
            else Bitmap.createScaledBitmap(source, w, h, true)
        try {
            val pixels = IntArray(w * h)
            small.getPixels(pixels, 0, w, 0, 0, w, h)
            val lum = FloatArray(pixels.size) { i ->
                val p = pixels[i]
                (0.2126f * ((p shr 16) and 255) +
                 0.7152f * ((p shr 8) and 255) +
                 0.0722f * (p and 255))
            }
            fun at(x: Int, y: Int) = lum[y * w + x]
            var best: Detection? = null
            val minSquare = max(12, min(w, h) / 40)
            val maxSquare = min(w, h) / 8
            val sizes = (minSquare..maxSquare.coerceAtLeast(minSquare)).filter {
                it % 2 == 0 || it == minSquare || it == maxSquare
            }
            for (s in sizes) {
                val board = s * 8
                if (board > w || board > h) continue
                val stride = max(2, s / 3)
                var y = 0
                while (y + board <= h) {
                    var x = 0
                    while (x + board <= w) {
                        val means = FloatArray(64)
                        var idx = 0
                        for (r in 0 until 8) for (c in 0 until 8) {
                            // Ignore grid lines, coordinates and highlighted edges.
                            var sum = 0f; var n = 0
                            for (fy in intArrayOf(35, 50, 65)) for (fx in intArrayOf(35, 50, 65)) {
                                sum += at(x + c * s + s * fx / 100, y + r * s + s * fy / 100)
                                n++
                            }
                            means[idx++] = sum / n
                        }
                        var light = 0f; var dark = 0f; var nl = 0; var nd = 0
                        for (r in 0 until 8) for (c in 0 until 8) {
                            val v = means[r * 8 + c]
                            if ((r + c) % 2 == 0) { light += v; nl++ } else { dark += v; nd++ }
                        }
                        val contrast = abs(light / nl - dark / nd)
                        // A chessboard should exhibit consistent parity across many squares.
                        var correct = 0
                        val expectedLight = light / nl > dark / nd
                        for (r in 0 until 8) for (c in 0 until 8) {
                            val isLight = means[r * 8 + c] > (light / nl + dark / nd) / 2f
                            if (isLight == (((r + c) % 2 == 0) == expectedLight)) correct++
                        }
                        val consistency = correct / 64f
                        val score = (contrast / 70f).coerceAtMost(1f) * 0.55f + consistency * 0.45f
                        if (score > (best?.score ?: 0f)) {
                            val inv = 1f / scale
                            best = Detection(Rect((x * inv).toInt(), (y * inv).toInt(),
                                ((x + board) * inv).toInt().coerceAtMost(source.width),
                                ((y + board) * inv).toInt().coerceAtMost(source.height)), score)
                        }
                        x += stride
                    }
                    y += stride
                }
            }
            return best?.takeIf { it.score >= 0.67f }
        } finally {
            if (small !== source) small.recycle()
        }
    }
}
