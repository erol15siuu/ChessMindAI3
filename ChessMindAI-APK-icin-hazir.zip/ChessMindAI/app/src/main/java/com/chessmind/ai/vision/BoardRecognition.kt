package com.chessmind.ai.vision

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import com.chessmind.ai.chess.FenPosition
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.max
import kotlin.math.min

/**
 * Model contract: assets/models/chess_square_classifier.tflite
 * input [1,64,64,3] float32 RGB [0,1], output [1,13] probabilities.
 * Classes: empty, P,N,B,R,Q,K,p,n,b,r,q,k.
 */
data class BoardDetection(
    val fen: FenPosition,
    val confidence: Float,
    val squareConfidence: List<Float>,
    val uncertainSquares: List<String>,
    val boardBounds: Rect? = null
)

interface BoardRecognizer {
    suspend fun recognize(bitmap: Bitmap, blackAtBottom: Boolean = false): Result<BoardDetection>
}

class TfliteBoardRecognizer(context: Context) : BoardRecognizer {
    private val interpreter: Interpreter? = runCatching {
        val file = context.cacheDir.resolve("chess_square_classifier.tflite")
        context.assets.open("models/chess_square_classifier.tflite").use { input ->
            file.outputStream().use(input::copyTo)
        }
        FileInputStream(file).channel.use { channel ->
            val mapped = channel.map(FileChannel.MapMode.READ_ONLY, 0, channel.size())
            Interpreter(mapped, Interpreter.Options().apply { setNumThreads(4) })
        }
    }.getOrNull()

    override suspend fun recognize(bitmap: Bitmap, blackAtBottom: Boolean): Result<BoardDetection> = runCatching {
        require(bitmap.width >= 256 && bitmap.height >= 256) { "Görüntü çok küçük" }
        val model = interpreter ?: error("Taş tanıma modeli eksik: app/src/main/assets/models/chess_square_classifier.tflite")
        val found = BoardCropper.locate(bitmap) ?: error("Satranç tahtası bulunamadı. Tahtayı tam ve düz açıyla içeren bir ekran görüntüsü seçin.")
        val rect = found.bounds
        val board = Bitmap.createBitmap(bitmap, rect.left, rect.top, rect.width(), rect.height())
        try {
            val classes = charArrayOf(' ', 'P', 'N', 'B', 'R', 'Q', 'K', 'p', 'n', 'b', 'r', 'q', 'k')
            val pieces = Array(8) { CharArray(8) { ' ' } }
            val confidences = ArrayList<Float>(64)
            val uncertain = ArrayList<String>()
            for (screenRank in 0 until 8) for (screenFile in 0 until 8) {
                val x0 = screenFile * board.width / 8
                val y0 = screenRank * board.height / 8
                val x1 = (screenFile + 1) * board.width / 8
                val y1 = (screenRank + 1) * board.height / 8
                val tile = Bitmap.createBitmap(board, x0, y0, x1 - x0, y1 - y0)
                val scaled = Bitmap.createScaledBitmap(tile, 64, 64, true)
                tile.recycle()
                try {
                    val input = ByteBuffer.allocateDirect(64 * 64 * 3 * 4).order(ByteOrder.nativeOrder())
                    val pixels = IntArray(64 * 64)
                    scaled.getPixels(pixels, 0, 64, 0, 0, 64, 64)
                    pixels.forEach { pixel ->
                        input.putFloat(((pixel shr 16) and 255) / 255f)
                        input.putFloat(((pixel shr 8) and 255) / 255f)
                        input.putFloat((pixel and 255) / 255f)
                    }
                    input.rewind()
                    val output = Array(1) { FloatArray(13) }
                    model.run(input, output)
                    val probs = output[0]
                    val classIndex = probs.indices.maxByOrNull { probs[it] } ?: 0
                    val confidence = probs[classIndex]
                    confidences += confidence
                    val rank = if (blackAtBottom) 7 - screenRank else screenRank
                    val file = if (blackAtBottom) 7 - screenFile else screenFile
                    val square = "${'a' + file}${8 - rank}"
                    if (confidence < 0.62f) uncertain += square
                    pieces[rank][file] = classes[classIndex]
                } finally { scaled.recycle() }
            }
            val placement = pieces.joinToString("/") { row ->
                buildString {
                    var empty = 0
                    row.forEach { piece ->
                        if (piece == ' ') empty++ else {
                            if (empty > 0) { append(empty); empty = 0 }
                            append(piece)
                        }
                    }
                    if (empty > 0) append(empty)
                }
            }
            val fen = FenPosition("$placement w - - 0 1")
            BoardDetection(fen, confidences.average().toFloat(), confidences, uncertain, rect)
        } finally { board.recycle() }
    }

    fun close() { interpreter?.close() }
}
