package com.chessmind.ai.chess

/**
 * Small FEN value object. Board parsing is intentionally strict so invalid
 * image-recognition output cannot silently be sent to the chess engine.
 */
data class FenPosition(val value: String) {
    init { require(isValid(value)) { "Geçersiz FEN pozisyonu" } }

    companion object {
        const val START = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

        fun isValid(fen: String): Boolean {
            val fields = fen.trim().split(Regex("\\s+"))
            if (fields.size != 6) return false
            val ranks = fields[0].split("/")
            if (ranks.size != 8) return false
            for (rank in ranks) {
                var count = 0
                for (c in rank) {
                    if (c in '1'..'8') count += c.digitToInt()
                    else if (c in "pnbrqkPNBRQK") count++
                    else return false
                }
                if (count != 8) return false
            }
            val placement = fields[0]
            if (placement.count { it == 'K' } != 1 || placement.count { it == 'k' } != 1) return false
            if (fields[1] !in listOf("w", "b")) return false
            if (fields[2] != "-" && (fields[2].any { it !in "KQkq" } || fields[2].toSet().size != fields[2].length)) return false
            if (fields[3] != "-" && !Regex(if (fields[1] == "w") "^[a-h]6$" else "^[a-h]3$").matches(fields[3])) return false
            return fields[4].toIntOrNull()?.let { it >= 0 } == true &&
                    fields[5].toIntOrNull()?.let { it >= 1 } == true
        }
    }
}
