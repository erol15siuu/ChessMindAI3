package com.chessmind.ai.capture

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import com.chessmind.ai.vision.TfliteBoardRecognizer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/** User-consented screen capture. Frames are processed on-device and never uploaded. */
class ScreenCaptureService : Service() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var recognizer: TfliteBoardRecognizer? = null
    private var lastFrameAt = 0L
    private var processing = false
    private var blackAtBottom = false

    override fun onCreate() {
        super.onCreate()
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(
            NotificationChannel("chess_capture", "ChessMind ekran takibi", NotificationManager.IMPORTANCE_LOW)
        )
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "chess_capture").setContentTitle("ChessMind AI")
                .setContentText("Ekran görüntüsü yerel olarak analiz ediliyor")
                .setSmallIcon(android.R.drawable.ic_menu_camera).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setContentTitle("ChessMind AI")
                .setContentText("Ekran görüntüsü yerel olarak analiz ediliyor")
                .setSmallIcon(android.R.drawable.ic_menu_camera).build()
        }
        if (Build.VERSION.SDK_INT >= 29) startForeground(41, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(41, notification)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        blackAtBottom = intent?.getBooleanExtra(EXTRA_BLACK_BOTTOM, false) ?: false
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
            else @Suppress("DEPRECATION") (intent?.getParcelableExtra(EXTRA_DATA))
        if (resultCode == 0 || data == null) { stopSelf(); return START_NOT_STICKY }
        runCatching {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            startProjection()
        }.onFailure { broadcastError(it.message ?: "Ekran yakalama başlatılamadı"); stopSelf() }
        return START_NOT_STICKY
    }

    private fun startProjection() {
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi
        reader = ImageReader.newInstance(width, height, android.graphics.PixelFormat.RGBA_8888, 2)
        recognizer = TfliteBoardRecognizer(this)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, null)
        display = projection?.createVirtualDisplay(
            "ChessMindCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, null
        )
        reader?.setOnImageAvailableListener({ source ->
            val now = SystemClock.elapsedRealtime()
            if (processing || now - lastFrameAt < 1200) {
                source.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            processing = true
            lastFrameAt = now
            serviceScope.launch {
                try {
                    val bitmap = imageToBitmap(image)
                    // The recognizer takes a centered square crop. Full-screen board localization
                    // is a separate CV stage and must be calibrated for each screen layout.
                    recognizer?.recognize(bitmap, blackAtBottom)?.onSuccess { detection ->
                        sendBroadcast(Intent(ACTION_POSITION).setPackage(packageName)
                            .putExtra(EXTRA_FEN, detection.fen.value)
                            .putExtra(EXTRA_CONFIDENCE, detection.confidence))
                    }?.onFailure { broadcastError(it.message ?: "Tahta tanınamadı") }
                    bitmap.recycle()
                } catch (t: Throwable) {
                    broadcastError(t.message ?: "Kare işlenemedi")
                } finally {
                    image.close()
                    processing = false
                }
            }
        }, null)
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val padded = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888
        )
        padded.copyPixelsFromBuffer(plane.buffer)
        val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return cropped
    }

    private fun broadcastError(message: String) {
        sendBroadcast(Intent(ACTION_ERROR).setPackage(packageName).putExtra(EXTRA_ERROR, message))
    }

    override fun onDestroy() {
        reader?.setOnImageAvailableListener(null, null)
        display?.release(); reader?.close(); projection?.stop(); recognizer?.close()
        serviceScope.cancel()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.chessmind.ai.STOP_CAPTURE"
        const val ACTION_POSITION = "com.chessmind.ai.POSITION"
        const val ACTION_ERROR = "com.chessmind.ai.CAPTURE_ERROR"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        const val EXTRA_FEN = "fen"
        const val EXTRA_CONFIDENCE = "confidence"
        const val EXTRA_ERROR = "error"
        const val EXTRA_BLACK_BOTTOM = "black_bottom"
    }
}
