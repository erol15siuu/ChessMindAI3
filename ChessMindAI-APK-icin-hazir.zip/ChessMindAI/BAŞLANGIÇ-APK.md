# ChessMindAI APK oluşturma (Türkçe)

Bu klasör Android uygulamasının kaynak kodudur; içinde hazır APK yoktur.

## GitHub üzerinden APK üretme

1. GitHub'da yeni ve boş bir depo oluşturun: https://github.com/new
2. Bu klasörün **içindeki tüm dosya ve klasörleri** depoya yükleyin. `.github` klasörünün de yüklendiğinden emin olun. ZIP dosyasının kendisini depoya yüklemek yeterli değildir.
3. Depoda **Actions** sekmesini açın.
4. Soldan **Build Android APK** iş akışını seçin.
5. **Run workflow** düğmesine basın.
6. İşlem yeşil tik ile tamamlanırsa çalıştırma sayfasının altındaki **Artifacts** bölümünden `ChessMindAI-debug-apk` dosyasını indirin.
7. İndirilen ZIP'i telefonda açın. İçindeki `app-debug.apk` dosyasına dokunup kurulumu başlatın.

## Önemli

- Bu işlem debug/test APK'sı üretir; Play Store için imzalı sürüm değildir.
- Android 8.0 veya üstü hedeflenmiştir.
- Kaynakta satranç tahtası tanıma kodu var, ancak eğitilmiş `chess_square_classifier.tflite` modeli yok.
- Stockfish Android çalıştırılabilir dosyası da dahil değildir. Bu iki varlık eklenmeden otomatik taş tanıma ve motor analizi tam çalışmaz.
- GitHub Actions derlemesi hata verirse Actions sayfasındaki hata günlüğü incelenmelidir.
