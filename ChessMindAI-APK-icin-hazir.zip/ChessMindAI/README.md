# ChessMind AI — Android development build

Kotlin + Jetpack Compose chess coach for Android. This is a development source
project, not a signed/release APK.

## Implemented in source

- Dark Jetpack Compose analysis interface.
- FEN placement validation (8 ranks, 8 files per rank, one king per side).
- Stockfish UCI process adapter with MultiPV variations and score/depth parsing.
- Best-move arrow overlay and Turkish heuristic coach note.
- Generic flat-board locator for screenshot images: scans for the alternating
  light/dark 8x8 square pattern and extracts an axis-aligned board crop. It is
  designed for Chess.com/Lichess-style flat screen captures and may need tuning
  for unusual themes, overlays, coordinates, or low-contrast boards.
- TFLite inference pipeline classifying 64 square crops into empty + 12 pieces.
- Gallery image selection and confidence/uncertain-square reporting.
- MediaProjection foreground service that captures screen frames locally,
  throttles recognition, broadcasts detected positions, and triggers analysis
  when a newly detected position arrives.

## Required external assets — not included

### Piece-recognition model

Add `app/src/main/assets/models/chess_square_classifier.tflite`.

Contract:
- Input float32 `[1,64,64,3]`, RGB values `[0,1]`.
- Output float32 `[1,13]` probabilities.
- Class order: `empty, P,N,B,R,Q,K,p,n,b,r,q,k`.

The model must be trained and validated against both Chess.com and Lichess
board themes, multiple piece sets, scaling, anti-aliasing, last-move highlights,
legal-move dots and coordinate labels. The app deliberately reports a clear
error if the model is absent; it does not invent piece positions.

### Stockfish Android executable

Add legally built Android binaries at the appropriate paths, e.g.:

- `app/src/main/assets/stockfish/arm64-v8a/stockfish`
- `app/src/main/assets/stockfish/armeabi-v7a/stockfish`
- `app/src/main/assets/stockfish/x86_64/stockfish`

Stockfish is GPL-licensed. Verify the exact release's licensing and source
redistribution obligations before bundling binaries in an APK.

## Recognition limitations

- The screenshot board locator currently targets axis-aligned, flat 2D boards.
  It is not a perspective/homography detector for photographed physical boards.
- Piece recognition quality depends entirely on the external trained TFLite
  model. No model is bundled in this repository.
- Static images cannot reliably reveal side-to-move, castling rights, en-passant
  square, or move counters. The UI currently lets the user set side-to-move and
  basic castling metadata; counters/en-passant default to `- 0 1`.
- Live capture requires explicit Android MediaProjection approval and a trained
  model + Stockfish binary. Android may prohibit capture of secure/DRM surfaces.
- Turkish explanations are heuristic summaries of engine score/mate/PV, not a
  separate natural-language chess reasoning model.

## Build

Requirements: Android Studio, JDK 17+, Android SDK 35, Android Gradle Plugin
8.9.2. Open this directory in Android Studio, sync Gradle, add both external
assets above, then run on a physical Android device. This execution environment
does not contain Android SDK/Gradle and cannot produce or verify an APK.

## Privacy

Screen frames are processed locally. Capture starts only after the system's
MediaProjection consent prompt and is surfaced as a foreground notification.
No screenshot or position is uploaded by this project.

## Build an APK with GitHub Actions

This source archive includes `.github/workflows/android-apk.yml`. Upload the
project to a GitHub repository, then open **Actions → Build Android APK → Run
workflow**. When the workflow succeeds, download the `ChessMindAI-debug-apk`
artifact from that run. This produces an installable debug APK; it does not add
the optional TFLite piece-recognition model or Stockfish executable described
above, so those features remain unavailable until the assets are supplied.
